//
//  Contents.swift
//  submission
//
//  Created by Sanika Surose on 2026-01-11.
//

import SwiftUI
import UIKit
import UniformTypeIdentifiers


struct PlaygroundHomeView: View {
    @State private var rawText: String = """
Take 500mg of aspirin by mouth every 6 hours as needed for pain. Follow up with your doctor in 3 days if pain does not improve.
"""
    @State private var simplifiedText: String = ""
    @State private var actions: [String] = []
    @State private var meds: [ExtractedMedication] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var selectedImage: UIImage?
    @State private var showImagePicker = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    Text("understand your prescription")
                        .font(.title2).bold()

                    Button("Upload Image (OCR)") {
                        showImagePicker = true
                    }
                    .buttonStyle(.bordered)
                    
                    // Input
                    Text("Paste medical text:")
                        .font(.headline)

                    TextEditor(text: $rawText)
                        .frame(height: 140)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(.gray.opacity(0.4))
                        )

                    // Button
                    Button {
                        Task {
                            await processText()
                        }
                    } label: {
                        if isLoading {
                            ProgressView()
                        } else {
                            Text("Simplify & Extract")
                                .bold()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isLoading || rawText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    if let errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }

                    // Simplified output
                    if !simplifiedText.isEmpty {
                        Divider()
                        Text("Simplified Explanation")
                            .font(.headline)
                        Text(simplifiedText)
                            .padding(8)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }

                    // Actions
                    if !actions.isEmpty {
                        Divider()
                        Text("What you need to do")
                            .font(.headline)
                        ForEach(actions, id: \.self) { action in
                            HStack(alignment: .top) {
                                Text("•")
                                Text(action)
                            }
                        }
                    }

                    // Medications
                    if !meds.isEmpty {
                        Divider()
                        Text("Medications")
                            .font(.headline)
                        ForEach(meds, id: \.id) { med in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(med.name).bold()
                                if let strength = med.strength { Text("Strength: \(strength)") }
                                if let form = med.form { Text("Form: \(form)") }
                                if let route = med.route { Text("Route: \(route)") }
                                if let frequency = med.frequency { Text("Frequency: \(frequency)") }
                                if let duration = med.duration { Text("Duration: \(duration)") }
                                if let instructions = med.instructions { Text("Notes: \(instructions)") }
                            }
                            .padding(8)
                            .background(Color.blue.opacity(0.05))
                            .cornerRadius(8)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("clairity")
            
            .fileImporter(
                isPresented: $showImagePicker,
                allowedContentTypes: [.image]
            ) { result in
                do {
                    let url = try result.get()
                    let data = try Data(contentsOf: url)

                    guard let image = UIImage(data: data) else {
                        errorMessage = "Invalid image"
                        return
                    }

                    selectedImage = image

                    // Run OCR immediately
                    Task {
                        do {
                            let text = try await OCRService.extractText(from: image)
                            rawText = text ?? ""
                        } catch {
                            errorMessage = error.localizedDescription
                        }
                    }

                } catch {
                    errorMessage = "Failed to load image"
                }
            }

        }
    }

    // MARK: - Logic using your GeminiService / OpenAIService

    func processText() async {
        isLoading = true
        errorMessage = nil
        simplifiedText = ""
        actions = []
        meds = []

        do {
            // 1) Simplify text using Gemini
            let simple = try await GeminiService.simplifyText(rawText)
            simplifiedText = simple.isEmpty ? rawText : simple

            // 2) Extract actions via Gemini
            let extractedActions = try await GeminiService.extractActions(from: simplifiedText)
            actions = extractedActions

            // 3) Extract meds via Gemini
            let extractedMeds = try await GeminiService.extractMeds(from: simplifiedText)
            meds = extractedMeds

        } catch {
            // Optional: fall back to OpenAIService heuristics on error
            simplifiedText = await OpenAIService.simplifyText(rawText)
            actions = OpenAIService.extractActions(from: simplifiedText)
            // meds = OpenAIService.extractMedications(from: simplifiedText) // you can map to ExtractedMedication if needed

            errorMessage = error.localizedDescription
            print("Gemini error:", error)
        }

        isLoading = false
    }
}

