//
//  SystemServices.swift
//  submission
//
//  Created by Sanika Surose on 2026-01-11.
//

import Foundation
@preconcurrency import UserNotifications
import Vision
import UIKit
import Translation

class NotificationService {
    static func scheduleReminders(_ reminders: [Reminder]) {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound]) { granted, error in
            if let error = error {
                print("Notification Authorization Error: \(error)")
                return
            }
            
            if granted {
                for reminder in reminders {
                    let content = UNMutableNotificationContent()
                    content.title = "Health Reminder"
                    content.body = reminder.message
                    content.sound = .default
                    
                    let components = Calendar.current.dateComponents(
                        [.year, .month, .day, .hour, .minute],
                        from: reminder.date
                    )
                    let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                    let request = UNNotificationRequest(
                        identifier: UUID().uuidString,
                        content: content,
                        trigger: trigger
                    )
                    
                    center.add(request) { addError in
                        if let addError = addError {
                            print("Error scheduling notification: \(addError)")
                        }
                    }
                }
            }
        }
    }
}

class OCRService {
    static func extractText(from image: UIImage) async -> String? {
        guard let cgImage = image.cgImage else { return nil }
        
        let request = VNRecognizeTextRequest { request, error in
            if let error = error {
                print("OCR Error: \(error)")
                return
            }
        }
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        do {
            try handler.perform([request])
            guard let observations = request.results else {
                return nil
            }
            return observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }.joined(separator: " ")
        } catch {
            print("OCR Handler Error: \(error)")
            return nil
        }
    }
}

class TranslationService {
    static func translate(_ text: String, to language: String) async -> String {
        // Use Apple's Translation (iOS 15+)
        // Note: Requires user permission; placeholder for now
        return text // Implement full translation if needed
    }
}
