//
//  Models.swift
//  submission
//
//  Created by Sanika Surose on 2026-01-11.
//

import Foundation
import UIKit

struct AfterCarePlan {
    var dailyPlans: [DailyPlan]
    var triggers: [Trigger]
    var reminders: [Reminder]
}

struct DailyPlan {
    var day: Int
    var tasks: [String]
}

struct ExtractedMedication: Codable, Identifiable, Hashable {
    var id: UUID = UUID()

    let name: String
    let strength: String?
    let form: String?
    let route: String?
    let frequency: String?
    let duration: String?
    let instructions: String?

    // Exclude `id` from JSON decoding/encoding
    enum CodingKeys: String, CodingKey {
        case name, strength, form, route, frequency, duration, instructions
    }
}

struct MedListJSON: Codable {
    let medications: [ExtractedMedication]
}

struct InputData {
    var text: String?
    var image: UIImage?  // Now works with UIKit import
    var diagnosis: String?
    var symptoms: [String]?
    var medications: [String]?
}

struct Medication {
    var name: String
    var dosage: String
    var duration: String
    var notes: String
}

struct ProcessedOutput {
    var simplifiedText: String
    var actions: [String]
    var medications: [Medication]
    var timeline: [TimelineItem]
    var recoverySigns: RecoverySigns
    var questions: [String]
}

struct RecoverySigns {
    var good: [String]
    var bad: [String]
}

struct Reminder {
    var date: Date
    var message: String
}

struct TimelineItem {
    var date: Date
    var tasks: [String]
}

struct Trigger {
    var condition: String
    var action: String
}
