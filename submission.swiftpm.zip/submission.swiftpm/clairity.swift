//
//  HealthSimplifyPlaygroundApp.swift
//  submission
//
//  Created by Sanika Surose on 2026-01-11.
//


import SwiftUI

@main
struct clairity: App {
    var body: some Scene {
        WindowGroup {
            PlaygroundHomeView()
        }
    }
}
